
import React, { useState, useEffect } from 'react';
import { GameView, GardenPlant, MoodEntry, AIResponse } from './types';
import Garden from './components/Garden';
import ReflectionPool from './components/ReflectionPool';
import BreathingStone from './components/BreathingStone';
import MoodStats from './components/MoodStats';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<GameView>(GameView.LANDING);
  const [plants, setPlants] = useState<GardenPlant[]>([]);
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  
  // Persistent Storage Simulation
  useEffect(() => {
    const savedPlants = localStorage.getItem('serenity_plants');
    const savedMoods = localStorage.getItem('serenity_moods');
    if (savedPlants) setPlants(JSON.parse(savedPlants));
    if (savedMoods) setMoodHistory(JSON.parse(savedMoods));
  }, []);

  useEffect(() => {
    localStorage.setItem('serenity_plants', JSON.stringify(plants));
    localStorage.setItem('serenity_moods', JSON.stringify(moodHistory));
  }, [plants, moodHistory]);

  const handleAIGift = (gift: NonNullable<AIResponse['gardenGift']>, score: number) => {
    const newPlant: GardenPlant = {
      id: Math.random().toString(36).substr(2, 9),
      type: gift.plantType,
      color: gift.color,
      name: gift.plantName,
      datePlanted: Date.now(),
      position: { 
        x: 10 + Math.random() * 80, 
        y: 5 + Math.random() * 20 
      }
    };
    setPlants(prev => [...prev, newPlant]);
    setMoodHistory(prev => [...prev, {
      timestamp: Date.now(),
      score: score,
      label: gift.plantName
    }]);
  };

  const NavItem: React.FC<{ view: GameView; icon: string; label: string }> = ({ view, icon, label }) => (
    <button
      onClick={() => setCurrentView(view)}
      className={`flex flex-col items-center p-3 rounded-2xl transition-all ${
        currentView === view ? 'bg-white shadow-lg text-emerald-700 scale-110' : 'text-emerald-800/60 hover:text-emerald-800'
      }`}
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-[10px] font-bold mt-1 uppercase tracking-tighter">{label}</span>
    </button>
  );

  if (currentView === GameView.LANDING) {
    return (
      <div className="min-h-screen bg-[#f0f4f1] flex flex-col items-center justify-center p-6 text-center">
        <div className="max-w-2xl space-y-8">
          <div className="animate-drift">
            <h1 className="text-6xl md:text-8xl font-bold text-emerald-900 mb-4">Serenity Grove</h1>
            <p className="text-xl md:text-2xl text-emerald-800/70 font-medium">Your personal sanctuary for peace, reflection, and growth.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-8">
            <div className="p-6 bg-white/60 rounded-3xl border border-white shadow-sm hover:shadow-md transition-shadow">
              <div className="text-4xl mb-3">🌿</div>
              <h3 className="font-bold text-emerald-900 mb-2">Build a Garden</h3>
              <p className="text-sm text-slate-600">Watch your mental resilience take physical form as a beautiful grove.</p>
            </div>
            <div className="p-6 bg-white/60 rounded-3xl border border-white shadow-sm hover:shadow-md transition-shadow">
              <div className="text-4xl mb-3">💬</div>
              <h3 className="font-bold text-emerald-900 mb-2">Speak Freely</h3>
              <p className="text-sm text-slate-600">Our compassionate AI guide listens without judgment and offers support.</p>
            </div>
            <div className="p-6 bg-white/60 rounded-3xl border border-white shadow-sm hover:shadow-md transition-shadow">
              <div className="text-4xl mb-3">🧘</div>
              <h3 className="font-bold text-emerald-900 mb-2">Guided Peace</h3>
              <p className="text-sm text-slate-600">Take a moment for guided breathing and grounding exercises.</p>
            </div>
          </div>

          <button 
            onClick={() => setCurrentView(GameView.GARDEN)}
            className="group relative px-12 py-5 bg-emerald-800 text-white rounded-full font-bold text-xl overflow-hidden shadow-2xl hover:scale-105 transition-transform"
          >
            <span className="relative z-10">Step Into The Grove</span>
            <div className="absolute inset-0 bg-emerald-700 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>
          
          <p className="text-xs text-slate-500 mt-8 max-w-sm mx-auto">
            Disclaimer: Serenity Grove is a supportive tool and does not provide professional medical advice. Please consult a specialist for mental health treatment.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f9f7] pb-24">
      {/* Top Header */}
      <header className="p-6 flex items-center justify-between">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentView(GameView.LANDING)}>
          <div className="w-10 h-10 bg-emerald-700 rounded-xl flex items-center justify-center text-white text-xl">🌱</div>
          <h1 className="text-2xl font-bold text-emerald-900 tracking-tight">Serenity Grove</h1>
        </div>
        <div className="hidden md:flex space-x-2 bg-white/50 p-1 rounded-full border border-white/40">
           <button onClick={() => setCurrentView(GameView.GARDEN)} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${currentView === GameView.GARDEN ? 'bg-emerald-700 text-white' : 'text-emerald-800 hover:bg-white/50'}`}>My Grove</button>
           <button onClick={() => setCurrentView(GameView.REFLECTION)} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${currentView === GameView.REFLECTION ? 'bg-emerald-700 text-white' : 'text-emerald-800 hover:bg-white/50'}`}>Reflect</button>
           <button onClick={() => setCurrentView(GameView.BREATH)} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${currentView === GameView.BREATH ? 'bg-emerald-700 text-white' : 'text-emerald-800 hover:bg-white/50'}`}>Breathe</button>
           <button onClick={() => setCurrentView(GameView.STATS)} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${currentView === GameView.STATS ? 'bg-emerald-700 text-white' : 'text-emerald-800 hover:bg-white/50'}`}>Trends</button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-6xl mx-auto px-6 py-4">
        {currentView === GameView.GARDEN && (
          <div className="space-y-8">
            <Garden plants={plants} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="bg-white p-8 rounded-3xl shadow-xl flex items-center space-x-6">
                 <div className="text-5xl">🧘‍♀️</div>
                 <div>
                   <h3 className="text-xl font-bold text-slate-800">Ready to talk?</h3>
                   <p className="text-slate-500 mb-4">Sharing your feelings helps your garden grow more vibrant.</p>
                   <button onClick={() => setCurrentView(GameView.REFLECTION)} className="bg-emerald-600 text-white px-6 py-2 rounded-full font-bold hover:bg-emerald-700 transition-colors">Start Reflection</button>
                 </div>
               </div>
               <div className="bg-sky-50 p-8 rounded-3xl shadow-xl flex items-center space-x-6 border border-sky-100">
                 <div className="text-5xl">🌬️</div>
                 <div>
                   <h3 className="text-xl font-bold text-sky-900">Need a break?</h3>
                   <p className="text-sky-700/70 mb-4">Try a 2-minute breathing session to reset your nervous system.</p>
                   <button onClick={() => setCurrentView(GameView.BREATH)} className="bg-sky-600 text-white px-6 py-2 rounded-full font-bold hover:bg-sky-700 transition-colors">Take a Breath</button>
                 </div>
               </div>
            </div>
          </div>
        )}

        {currentView === GameView.REFLECTION && (
          <div className="max-w-4xl mx-auto">
            <ReflectionPool onAIGift={handleAIGift} />
          </div>
        )}

        {currentView === GameView.BREATH && (
          <div className="max-w-2xl mx-auto">
            <BreathingStone />
          </div>
        )}

        {currentView === GameView.STATS && (
          <div className="max-w-4xl mx-auto">
            <MoodStats entries={moodHistory} />
          </div>
        )}
      </main>

      {/* Persistent Bottom Nav (Mobile/Desktop) */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-emerald-50/90 backdrop-blur-xl border border-white px-6 py-3 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] flex space-x-8 z-50">
        <NavItem view={GameView.GARDEN} icon="🏡" label="Grove" />
        <NavItem view={GameView.REFLECTION} icon="💧" label="Reflect" />
        <NavItem view={GameView.BREATH} icon="🧘" label="Center" />
        <NavItem view={GameView.STATS} icon="📊" label="Path" />
      </nav>
    </div>
  );
};

export default App;
