
import React from 'react';

export const COLORS = {
  sage: '#8fae92',
  lavender: '#b8a6d1',
  sky: '#aed9e0',
  sand: '#f5ebe0',
  deepGreen: '#4a5d4d',
  softRose: '#e8c2ca',
};

export const PLANT_ICONS = {
  flower: (color: string) => (
    <svg viewBox="0 0 100 100" className="w-full h-full" fill={color}>
      <circle cx="50" cy="50" r="10" fill="#fcd34d" />
      <circle cx="50" cy="30" r="15" />
      <circle cx="70" cy="40" r="15" />
      <circle cx="70" cy="65" r="15" />
      <circle cx="50" cy="75" r="15" />
      <circle cx="30" cy="65" r="15" />
      <circle cx="30" cy="40" r="15" />
      <rect x="48" y="70" width="4" height="30" fill="#4ade80" />
    </svg>
  ),
  tree: (color: string) => (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      <rect x="45" y="60" width="10" height="40" fill="#78350f" />
      <circle cx="50" cy="40" r="30" fill={color} />
      <circle cx="35" cy="50" r="20" fill={color} />
      <circle cx="65" cy="50" r="20" fill={color} />
    </svg>
  ),
  shrub: (color: string) => (
    <svg viewBox="0 0 100 100" className="w-full h-full" fill={color}>
      <ellipse cx="50" cy="70" rx="40" ry="25" />
      <ellipse cx="30" cy="60" rx="25" ry="20" />
      <ellipse cx="70" cy="60" rx="25" ry="20" />
    </svg>
  ),
  stone: (color: string) => (
    <svg viewBox="0 0 100 100" className="w-full h-full" fill={color}>
      <path d="M20,80 Q30,40 50,40 T80,80 Z" />
      <path d="M10,85 Q20,60 40,70 T70,85 Z" opacity="0.7" />
    </svg>
  ),
};
