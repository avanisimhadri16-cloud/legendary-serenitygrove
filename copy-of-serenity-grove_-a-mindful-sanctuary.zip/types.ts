
export interface MoodEntry {
  timestamp: number;
  score: number; // 1 to 10
  label: string;
}

export interface GardenPlant {
  id: string;
  type: 'flower' | 'tree' | 'shrub' | 'stone';
  color: string;
  name: string;
  datePlanted: number;
  position: { x: number; y: number };
}

export interface AIResponse {
  message: string;
  suggestedAction: string;
  moodAnalysis: {
    score: number;
    dominantEmotion: string;
  };
  gardenGift?: {
    plantName: string;
    plantType: 'flower' | 'tree' | 'shrub' | 'stone';
    color: string;
  };
}

export enum GameView {
  LANDING = 'LANDING',
  GARDEN = 'GARDEN',
  REFLECTION = 'REFLECTION',
  BREATH = 'BREATH',
  STATS = 'STATS'
}
