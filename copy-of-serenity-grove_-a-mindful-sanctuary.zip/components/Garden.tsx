
import React from 'react';
import { GardenPlant } from '../types';
import { PLANT_ICONS } from '../constants';

interface GardenProps {
  plants: GardenPlant[];
}

const Garden: React.FC<GardenProps> = ({ plants }) => {
  return (
    <div className="relative w-full h-[60vh] bg-gradient-to-b from-[#e0f2f1] to-[#c8e6c9] rounded-3xl border-8 border-white shadow-inner overflow-hidden">
      {/* Background elements */}
      <div className="absolute bottom-0 w-full h-32 bg-[#a5d6a7] rounded-t-[100%]" />
      
      {/* Dynamic Plants */}
      {plants.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-slate-500 opacity-50 space-y-4">
          <p className="text-xl italic">Your grove is waiting for its first seed...</p>
          <div className="w-16 h-16 border-2 border-dashed border-slate-400 rounded-full flex items-center justify-center">
            🌱
          </div>
        </div>
      ) : (
        plants.map((plant) => (
          <div
            key={plant.id}
            className="absolute animate-drift transition-all duration-1000 group cursor-pointer"
            style={{
              left: `${plant.position.x}%`,
              bottom: `${plant.position.y}%`,
              width: plant.type === 'tree' ? '80px' : '40px',
              height: plant.type === 'tree' ? '80px' : '40px',
              transform: 'translateX(-50%)'
            }}
          >
            <div className="w-full h-full">
              {PLANT_ICONS[plant.type](plant.color)}
            </div>
            {/* Tooltip */}
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded shadow-lg text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
              {plant.name}
            </div>
          </div>
        ))
      )}
      
      {/* Decorative details */}
      <div className="absolute top-10 right-10 w-16 h-16 bg-yellow-100 rounded-full blur-xl opacity-60" />
    </div>
  );
};

export default Garden;
