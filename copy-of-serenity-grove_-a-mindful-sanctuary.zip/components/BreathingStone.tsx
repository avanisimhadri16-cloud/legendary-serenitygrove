
import React, { useState, useEffect } from 'react';

const BreathingStone: React.FC = () => {
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [timer, setTimer] = useState(4);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setTimer((t) => {
          if (t <= 1) {
            if (phase === 'Inhale') { setPhase('Hold'); return 4; }
            if (phase === 'Hold') { setPhase('Exhale'); return 4; }
            if (phase === 'Exhale') { setPhase('Inhale'); return 4; }
            return 4;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isActive, phase]);

  const toggleBreathing = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setPhase('Inhale');
      setTimer(4);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-8 p-12 bg-sky-50 rounded-3xl border-4 border-white shadow-inner min-h-[500px]">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-sky-900">Breathing Stone</h2>
        <p className="text-sky-600">A moment of stillness for your mind.</p>
      </div>

      <div className="relative flex items-center justify-center">
        {/* Breathing Circle */}
        <div 
          className={`
            w-64 h-64 rounded-full border-[16px] border-white shadow-2xl transition-all duration-[4000ms] ease-in-out flex items-center justify-center bg-sky-200/50
            ${isActive && phase === 'Inhale' ? 'scale-125 bg-sky-300/60' : ''}
            ${isActive && phase === 'Exhale' ? 'scale-90 bg-sky-100/40' : ''}
          `}
        >
          <div className="text-center">
            <div className="text-4xl font-bold text-sky-800 mb-1">{isActive ? phase : 'Ready?'}</div>
            {isActive && <div className="text-2xl text-sky-600">{timer}</div>}
          </div>
        </div>
      </div>

      <button
        onClick={toggleBreathing}
        className={`px-10 py-4 rounded-full font-bold text-lg shadow-lg transition-all transform active:scale-95 ${
          isActive 
            ? 'bg-rose-100 text-rose-700 border-2 border-rose-200' 
            : 'bg-emerald-600 text-white hover:bg-emerald-700'
        }`}
      >
        {isActive ? 'Pause Journey' : 'Begin Breathing'}
      </button>

      <div className="flex space-x-4">
        {['Inhale', 'Hold', 'Exhale'].map((p) => (
          <div 
            key={p} 
            className={`w-3 h-3 rounded-full transition-colors ${phase === p && isActive ? 'bg-sky-500 scale-125' : 'bg-sky-200'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default BreathingStone;
