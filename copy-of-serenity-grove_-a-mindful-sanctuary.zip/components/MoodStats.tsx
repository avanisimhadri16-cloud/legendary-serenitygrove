
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { MoodEntry } from '../types';

interface MoodStatsProps {
  entries: MoodEntry[];
}

const MoodStats: React.FC<MoodStatsProps> = ({ entries }) => {
  const data = entries.map(e => ({
    name: new Date(e.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' }),
    score: e.score,
    label: e.label
  })).slice(-10); // Show last 10 entries

  return (
    <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800">Your Emotional Landscape</h2>
        <div className="text-sm text-slate-400">Past {data.length} reflections</div>
      </div>

      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
            <YAxis domain={[0, 10]} axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
            <Tooltip 
              contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
              labelStyle={{fontWeight: 'bold', color: '#1e293b'}}
            />
            <Area 
              type="monotone" 
              dataKey="score" 
              stroke="#10b981" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorScore)" 
              animationDuration={2000}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100 text-center">
          <div className="text-3xl mb-2">🌿</div>
          <div className="text-sm text-emerald-800 font-semibold uppercase tracking-wider">Growth Factor</div>
          <div className="text-2xl font-bold text-emerald-900">{entries.length} reflections</div>
        </div>
        <div className="bg-sky-50 p-6 rounded-2xl border border-sky-100 text-center">
          <div className="text-3xl mb-2">🌊</div>
          <div className="text-sm text-sky-800 font-semibold uppercase tracking-wider">Current Flow</div>
          <div className="text-2xl font-bold text-sky-900">
            {data.length > 0 ? (data[data.length - 1].score > 5 ? 'Steady' : 'Transitioning') : 'New Beginnings'}
          </div>
        </div>
        <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100 text-center">
          <div className="text-3xl mb-2">✨</div>
          <div className="text-sm text-amber-800 font-semibold uppercase tracking-wider">Mindfulness Streak</div>
          <div className="text-2xl font-bold text-amber-900">3 Days</div>
        </div>
      </div>
    </div>
  );
};

export default MoodStats;
