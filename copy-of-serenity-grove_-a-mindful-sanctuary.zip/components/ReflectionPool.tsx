
import React, { useState, useRef, useEffect } from 'react';
import { processReflection } from '../services/geminiService';
import { AIResponse } from '../types';

interface ReflectionPoolProps {
  onAIGift: (gift: NonNullable<AIResponse['gardenGift']>, moodScore: number) => void;
}

const ReflectionPool: React.FC<ReflectionPoolProps> = ({ onAIGift }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string; action?: string }[]>([
    { role: 'ai', text: "Welcome to the Reflection Pool. I am your Grove Guide. How are you feeling today?" }
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userText = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);

    const result = await processReflection(userText);
    
    setMessages(prev => [...prev, { 
      role: 'ai', 
      text: result.message, 
      action: result.suggestedAction 
    }]);

    if (result.gardenGift) {
      onAIGift(result.gardenGift, result.moodAnalysis.score);
    }
    
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-[70vh] bg-white/80 backdrop-blur-md rounded-3xl overflow-hidden shadow-xl border border-white">
      <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
        <h3 className="font-semibold text-slate-600">Reflection Pool</h3>
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-2xl ${
              m.role === 'user' 
                ? 'bg-emerald-600 text-white rounded-tr-none shadow-md' 
                : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200 shadow-sm'
            }`}>
              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
              {m.action && (
                <div className="mt-4 p-3 bg-white/50 rounded-lg text-emerald-800 text-sm font-medium border border-emerald-100">
                  🌱 Suggestion: {m.action}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 p-4 rounded-2xl rounded-tl-none flex space-x-2">
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 bg-slate-50 border-t border-slate-100">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Share your thoughts..."
            className="w-full bg-white border border-slate-200 rounded-full py-3 pl-5 pr-14 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-sm"
          />
          <button 
            type="submit"
            disabled={loading}
            className="absolute right-2 p-2 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 disabled:opacity-50 transition-colors shadow-md"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </button>
        </div>
        <p className="text-[10px] text-center text-slate-400 mt-2 italic">Your thoughts are private and safe here.</p>
      </form>
    </div>
  );
};

export default ReflectionPool;
