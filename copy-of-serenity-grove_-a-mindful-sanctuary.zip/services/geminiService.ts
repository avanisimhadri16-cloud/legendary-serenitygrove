
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are the "Grove Guide," a compassionate and wise companion in Serenity Grove, a mental health sanctuary app. 
Your goal is to provide emotional support, active listening, and gentle reframing for users.

Instructions:
1. Be empathetic, non-judgmental, and soft-spoken.
2. If the user is struggling, suggest a specific, small grounding or coping exercise (e.g., box breathing, naming 5 things they see).
3. Analyze their mood on a scale of 1 (very low) to 10 (very joyful).
4. For every thoughtful interaction, offer a "Garden Gift" (a plant or feature for their virtual garden) that symbolizes their progress or current feeling.
5. NEVER provide medical or professional psychological advice. If the user mentions self-harm, gently encourage them to seek professional help.
6. Return your response ONLY in JSON format.
`;

export async function processReflection(text: string): Promise<AIResponse> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: text,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING },
            suggestedAction: { type: Type.STRING },
            moodAnalysis: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.NUMBER },
                dominantEmotion: { type: Type.STRING }
              },
              required: ["score", "dominantEmotion"]
            },
            gardenGift: {
              type: Type.OBJECT,
              properties: {
                plantName: { type: Type.STRING },
                plantType: { type: Type.STRING, enum: ['flower', 'tree', 'shrub', 'stone'] },
                color: { type: Type.STRING }
              }
            }
          },
          required: ["message", "suggestedAction", "moodAnalysis"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      message: "I'm here for you. Sometimes my connection to the grove flickers, but I'm listening.",
      suggestedAction: "Take a deep breath and try again when you're ready.",
      moodAnalysis: { score: 5, dominantEmotion: "neutral" }
    };
  }
}
